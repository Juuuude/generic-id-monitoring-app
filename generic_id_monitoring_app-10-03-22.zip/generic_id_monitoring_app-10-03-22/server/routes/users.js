const express = require('express');
const ldap = require('ldapjs');
const router = express.Router();
const dbHelper = require('./db services/dbservice')

//set ldap options
const ldapOptions = {
    url: 'ldap://globalcatalog.fpl.com:3268',
    // url: 'ldap://GOXAD14.fplu.fpl.com:389',
    connectTimeout: 30000,
    reconnect: true,
    strictDN: false
};

//set ldap client
var client;

// get all login reports
router.post('/getFirstTenReports', async (req, res) => {
    try {
        const result = await dbHelper.getReports(req.body.table_name)
        res.send(result)
    } catch (err) {
        res.send(err)
    }
})

router.post('/searchReport', async (req, res) => {
    try {
        const result = await dbHelper.searchReport(req.body.table_name, req.body.search_param)
        res.send(result)
    } catch (err) {
        res.send(err)
    }
})

router.post('/searchReportCount', async (req, res) => {
    try {
        const count = await dbHelper.searchReportCount(req.body.table_name, req.body.search_param)
        res.send(count)
    } catch (err) {
        res.send(err)
    }
})

router.post('/paginateReport', async (req, res) => {
    try {
        const result = await dbHelper.paginateReport(req.body.table_name, req.body.search_param, req.body.offset)
        res.send(result)
    } catch (err) {
        res.send(err)
    }
})

router.post('/exportRecords', async (req, res) => {
    try {
        const result = await dbHelper.exportRecords(req.body.table_name, req.body.search_param)
        res.send(result)
    } catch (err) {
        res.send(err)
    }
})

router.post('/getCount', async (req, res) => {
    try {
        const count = await dbHelper.getCount(req.body.table_name)
        res.send(count)
    } catch(err) {
        res.send(err)
    }
})

//post application logout 
router.post('/app/logout', async (req, res) => {
    try {
        const response = await dbHelper.setLogout(req.body)
        res.send(response)
    } catch (err) {
        res.send(err)
    }
})

router.post('/login', async (req, res) => {

    client = ldap.createClient(ldapOptions);
    var slid = req.body.slid.toUpperCase();
    var password = req.body.password;

    client.bind(slid + '@fplu.fpl.com', password, async function (err, resp) {
        if (err) {
            return res.send({ LoginError: 'Invalid slid/password' })
        }
        // hasAccess = await checkPrivilege(slid)
        res.send({ slid: slid });
    });
    client.on('error', function (err) {
        console.warn('LDAP connection failed, waiting to reconnect...', err);
    });

    //open up db connection 
    try {
        await dbHelper.connection()
    } catch (err) {
        console.log(err)
    }

});

router.post('/logout', async (req, res) => {
    try {
        await dbHelper.onUserLogout()
        console.log('logout')
    } catch (err) {
        console.log(err)
    }
})


module.exports = router;


const oracledb = require('oracledb');
const dotenv = require('dotenv')

//set oracle db to auto commit
oracledb.autoCommit = true;

//read .env file
dotenv.config()

//set connection parameters for oracledb
con_params = {
    user: process.env.DB_USERNAME,
    password: process.env.DB_PASSWORD,
    connectString: process.env.DB_CONNECT_STRING
}

let connection = async () => {
    return connection = await oracledb.getConnection(con_params);
}

// update user data when the user click on logout button for the specfic app and region
const setLogout = async (user_data) => {

    let result;
    let query_string = `insert into ${user_data.table_name} values 
    ('${user_data.id}', '${user_data.slid}', '${user_data.app}', '${user_data.region}', 
    '${user_data.login_date}', '${user_data.logout_date}', '${user_data.login_duration}')`

    try {
        result = await connection.execute(query_string)
    } catch (err) {
        console.log(err)
    }
    return result;
}

// oracle query to fetch first 10 login reports
const getReports = async (table_name) => {
    let result;
    try {
        result = await connection.execute(`select * from ${table_name} order by logout_date desc fetch first 10 rows only`, [], { outFormat: oracledb.OBJECT })
    } catch (err) {
        console.log(err)
    }
    return result
}

// oracle query to fetch the search reports from reports page
const searchReport = async (table_name, param) => {

    let query_string = `select * from ${table_name} where slid like '%${param}%' or application 
    like '%${param}%' or region like '%${param}%' or login_date like '%${param}%' or logout_date 
    like '%${param}%' or login_duration like '%${param.toLowerCase()}%' order by logout_date desc
    fetch first 10 rows only`

    let result;

    try {
        result = await connection.execute(query_string, [], { outFormat: oracledb.OBJECT })
    } catch (err) {
        console.log(err)
    }
    return result
}

// oracle query to fetch the count of search reports
const searchReportCount = async (table_name, param) => {
    
    let query_count = `select count(*) as count from ${table_name} where slid like '%${param}%' or application 
    like '%${param}%' or region like '%${param}%' or login_date like '%${param}%' or logout_date 
    like '%${param}%' or login_duration like '%${param.toLowerCase()}%' order by logout_date desc`

    let count;

    try {
        count = await connection.execute(query_count, [], { outFormat: oracledb.OBJECT })
        return count.rows
    } catch (err) {
        console.log(err)
    }
}


// oracle query to paginate the report table
const paginateReport = async (table_name, param, offset) => {
    let query_string;
    let result;
    if (param === '') {
        query_string = `select * from ${table_name} order by logout_date desc 
        offset ${offset} rows fetch next 10 rows only`
    } else {
        query_string = `select * from ${table_name} where slid like '%${param}%' or application 
    like '%${param}%' or region like '%${param}%' or login_date like '%${param}%' or logout_date 
    like '%${param}%' or login_duration like '%${param.toLowerCase()}%' order by logout_date desc 
    offset ${offset} rows fetch next 10 rows only`
    }

    try {
        result = await connection.execute(query_string, [], { outFormat: oracledb.OBJECT })
    } catch (err) {
        console.log(err)
    }
    return result
}

// oracle query to paginate the report table
const exportRecords = async (table_name, param) => {
    let query_string;
    let result;
    if (param === '') {
        query_string = `select slid, application, region, login_date, logout_date, login_duration
         from ${table_name} order by logout_date desc`
    } else {
        query_string = `select slid, application, region, login_date, logout_date, login_duration 
        from ${table_name} where slid like '%${param}%' or application like '%${param}%' or region 
        like '%${param}%' or login_date like '%${param}%' or logout_date like '%${param}%' or 
        login_duration like '%${param.toLowerCase()}%' order by logout_date desc`
    }

    try {
        result = await connection.execute(query_string, [], { outFormat: oracledb.OBJECT })
    } catch (err) {
        console.log(err)
    }
    return result
}

const getCount = async (table_name) => {
    try {
        const count = await connection.execute(`select count(*) as count from ${table_name}`,
            [],
            { outFormat: oracledb.OBJECT })
        return count.rows
    } catch (err) {
        console.log(err)
    }
}

const onUserLogout = async () => {
    if (connection) {
        try {
            await connection.close()
            console.log('User logs out. Closing db connection...')
        } catch (err) {
            console.log('Unable to close db connection: ' + err)
        }

    }
}

module.exports = {
    setLogout,
    getReports,
    searchReport,
    paginateReport,
    exportRecords,
    getCount,
    searchReportCount,
    onUserLogout,
    connection
}
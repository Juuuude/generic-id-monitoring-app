export default {
    userLogin(context, payload) {
        context.commit('userLogin', payload)
    },
    userLogout(context) {
        context.commit('userLogout')
    },
    appLogin(context, payload){
        context.commit('appLogin', payload)
    },
    appLogout(context, payload){
        context.commit('appLogout', payload)
    },
    setNavTitle(context, payload) {
        context.commit('setNavTitle', payload)
    },
    setSelectedId(context, payload){
        context.commit('setSelectedId', payload)
    },
    async loadAllUsers(context){
        const response = await fetch('https://generic-id-monitoring-app-default-rtdb.firebaseio.com/users.json')
        const responseData = await response.json()

        if(!response.ok) {
            const error = new Error('Failed to fetch data! Please try again later.')
            throw error;
        }

        const usersData = []
        for(const id in responseData){ 
            const user = {
                id: id,
                nams: responseData[id].nams,
                dctm: responseData[id].dctm,
                ewp: responseData[id].ewp
            }
            usersData.push(user)
            context.commit('loadAllUsers', usersData)
        }
    }
}
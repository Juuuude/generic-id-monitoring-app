export default {
    getUsers(state) {
        return state.listOfUsers
    },
    getUserId(state){
        return state.userId
    },
    getAuthentication(state) {
        return state.isLoggedin
    },
    getNavTitle(state){
        return state.navTitle
    },
    //get the details of logged in user
    getLoggedinUser(state){
        const userId = state.userId
        return state.listOfUsers.find((user) => user.id === userId)
    },
    //get the details of the selected user in view details page
    getSelectedUser(state){
        const selectedId = state.selectedId
        return state.listOfUsers.find((user) => user.id === selectedId)
        
    }
}
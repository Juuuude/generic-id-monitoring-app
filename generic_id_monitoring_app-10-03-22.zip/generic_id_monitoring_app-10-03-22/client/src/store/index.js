import { createStore } from 'vuex'
import mutations from './mutations.js'
import actions from './actions.js'
import getters from './getters.js'

const store = createStore({
    state() {
        return {
            //store the logged in userId
            userId: localStorage.getItem('slid'),
            isLoggedin: localStorage.getItem('isLoggedin'),
            //store the id of the selected user 
            selectedId: '',
            isAuthenticated: true,
            navTitle: 'Generic ID Monitoring Page',
            listOfUsers: []
        }
    },
    mutations,
    actions,
    getters
})

export default store;
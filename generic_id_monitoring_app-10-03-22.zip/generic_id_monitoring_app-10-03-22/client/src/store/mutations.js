import { getDatabase, ref, update } from "firebase/database";
export default {
    userLogin(state, payload){
        state.userId = payload.slid
        state.isLoggedin = payload.isLoggedin
    },
    userLogout(state) {
        state.isLoggedin = ''
    },

    async appLogin(state, payload) {
        const id = state.userId
        const db = getDatabase()

        // update firebase database to set the user to logged in 
        try {
            await update(ref(db, `users/${id}/${payload.app}/0/${payload.region}/0/`), {
                status: 'Logged in',
            })
        } catch (err) {
            console.log(err)
        }

        //updating lastLogin date field in firebase
        try {
            await update(ref(db, `users/${id}/${payload.app}/0/${payload.region}/1/`), {
                lastLogin: payload.lastLogin,
            })
        } catch (err) {
            console.log(err)
        }
    },
    async appLogout(state, payload) {
        const id = state.userId

        //updating logout
        try {
            const db = getDatabase();
            await update(ref(db, `users/${id}/${payload.app}/0/${payload.region}/0/`), {
                status: 'Not using',
            })
        } catch (err) {
            console.log(err)
        }
    },
    loadAllUsers(state, payload) {
        state.listOfUsers = payload
    },
    setNavTitle(state, payload) {
        state.navTitle = payload
    },
    setSelectedId(state, payload) {
        state.selectedId = payload
    }
}
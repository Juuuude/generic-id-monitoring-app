import axios from 'axios'

const url = 'http://10.110.60.111:8084'

class AppAccessService {
    static async userLogout(id, slid, table_name, app, region, login_date, logout_date, login_duration) {
        try {
            await axios.post(`${url}/app/logout`, { id, slid, table_name, app, region, login_date, logout_date, login_duration })
        } catch (err) {
            console.log(err)
        }
    }
}

export default AppAccessService;
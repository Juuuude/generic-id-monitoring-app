import axios from 'axios'

const url = 'http://10.110.60.111:8084'

class LoginService {
	
    //login authentication
    static async login(slid, password) {
        try {
            const hasAccount = await axios.post(`${url}/login`, {slid, password})
            return hasAccount
        }catch (err) {
            console.log(err)
        }
    }

    //logout
    static async logout() {
        try {
            await axios.post(`${url}/logout`)
        }catch (err) {
            console.log(err)
        }
    }

    //get username
    static async getSlid() {
        try{
            await axios.get(`${url}/getSlid`)
        }catch (err) {
            console.log(err)
        }
    }
}

export default LoginService;
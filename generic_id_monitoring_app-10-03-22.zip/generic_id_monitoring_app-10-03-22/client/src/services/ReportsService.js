import axios from 'axios'

const url = 'http://10.110.60.111:8084'

class ReportsService {

    static async getFirstTenReports(table_name) {
        try {
            const result = await axios.post(`${url}/getFirstTenReports`, { table_name })
            return result
        } catch (err) {
            console.log(err)
        }
    }
    
    static async searchReport(table_name, search_param) {
        try {
            const result = await axios.post(`${url}/searchReport`, { table_name, search_param })
            return result
        } catch (err) {
            console.log(err)
        }
    }

    static async searchReportCount(table_name, search_param) {
        try {
            const count = await axios.post(`${url}/searchReportCount`, { table_name, search_param })
            return count
        } catch (err) {
            console.log(err)
        }
    }

    static async paginateReport(table_name, search_param, offset) {
        try {
            const result = await axios.post(`${url}/paginateReport`, { table_name, search_param, offset })
            return result
        } catch (err) {
            console.log(err)
        }
    }

    static async exportRecords(table_name, search_param){
        try {
            const result = await axios.post(`${url}/exportRecords`, { table_name, search_param })
            return result
        } catch (err) {
            console.log(err)
        }
    }
    
    static async getCount(table_name) {
        try {
            const count = await axios.post(`${url}/getCount`, { table_name })
            return count
        }catch (err) {
            console.log(err)
        }
    }
}

export default ReportsService
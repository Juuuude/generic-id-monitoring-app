<template>
  <div class="container mt-3">
    <div class="container my-2">
      <div class="d-flex">
        <p class="fw-bold mt-2">Viewing report for: &nbsp;</p>
        <div>
          <select
            name=""
            id=""
            class="form-control"
            v-model="table_name"
            @change="appChange"
          >
            <option value="fpl_nams_access" selected>NAMS</option>
            <option value="fpl_dctm_access">DCTM</option>
            <option value="fpl_ewp_access">EWP</option>
          </select>
        </div>
        <div class="mx-auto" style="width: 400px">
          <input
            type="text"
            class="form-control"
            placeholder="&#xF002; Search"
            style="font-family: Arial, FontAwesome"
            v-model="search_string"
          />
        </div>
        <div>
          <button class="btn btn-success" :class="exportBtnClass" @click="exportRecords">
            <i class="fa-solid fa-file-export me-1"></i>Export to Excel
          </button>
        </div>
      </div>

      <!-- loading spinner -->
      <div class="container" v-if="isLoading">
        <div class="row">
          <div class="col">
            <loading-spinner></loading-spinner>
          </div>
        </div>
      </div>
    </div>
    <table
      class="table table-bordered table-striped table-success"
      v-if="!isLoading"
    >
      <thead>
        <tr>
          <th scope="col">#</th>
          <th class="table-header" scope="col">SLID</th>
          <th class="table-header" scope="col">Application</th>
          <th class="table-header" scope="col">Region</th>
          <th class="table-header" scope="col">Login Date</th>
          <th class="table-header" scope="col">Logout Date</th>
          <th class="table-header" scope="col">Login Duration</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(report, i) in listOfReports" :key="report.id">
          <th scope="row">{{ i + 1 }}</th>
          <td>{{ report.SLID }}</td>
          <td>{{ report.APPLICATION }}</td>
          <td>{{ report.REGION }}</td>
          <td>{{ report.LOGIN_DATE }}</td>
          <td>{{ report.LOGOUT_DATE }}</td>
          <td>{{ report.LOGIN_DURATION }}</td>
        </tr>
      </tbody>
    </table>

    <!-- no records found -->
    <div class="container" v-if="listOfReports.length < 1 && !isLoading">
      <div class="row">
        <div class="col">
          <p>No records found.</p>
        </div>
      </div>
    </div>
    <nav v-if="listOfReports.length > 0" aria-label="Page navigation">
      <ul class="pagination justify-content-center">
        <li class="page-item">
          <a class="page-link" :class="prevBtnClass" @click="prevPage()">Previous</a>
        </li>
        <!-- <li class="page-item"><a class="page-link"> &lt;&lt; </a></li> -->
        <li v-for="page in pages" :key="page" class="page-item">
          <a
            style="cursor: pointer"
            class="page-link"
            :class="{ 'page-item': true, active: curr_page == page }"
            @click="paginate(page)"
            >{{ page }}</a
          >
        </li>
        <!-- <li class="page-item"><a class="page-link"> &gt;&gt; </a></li> -->
        <li class="page-item">
          <a class="page-link" :class="nextBtnClass" @click="nextPage()">Next</a>
        </li>
      </ul>
    </nav>
  </div>
</template>

<script>
import ReportsService from "../../services/ReportsService";
import exportFromJSON from "export-from-json";

export default {
  data() {
    return {
      listOfReports: [],
      pages: [],
      recordsToExport: [],
      table_name: "fpl_nams_access",
      numOfPage: 0,
      count: 0,
      curr_page: 1,
      isActive: true,
      search_string: '',
      isLoading: false,
    };
  },

  created() {
    this.getFirstTenReports();
  },

  watch: {
    search_string() {
      this.curr_page = 1;
      this.searchRecords();
    },
  },
  computed: {
    prevBtnClass() {
      return this.curr_page === 1 ? 'disabled' : ''
    },
    nextBtnClass() {
      return this.curr_page === this.numOfPage ? 'disabled' : ''
    },
    exportBtnClass() {
      return this.listOfReports.length === 0 ? 'disabled' : ''
    }
  },
  methods: {
    async getFirstTenReports() {
      this.isLoading = true;

      this.getRecordCount();
      try {
        const result = await ReportsService.getFirstTenReports(this.table_name);
        const resultData = result.data;
        this.listOfReports = resultData.rows;
        this.isLoading = false;
      } catch (err) {
        console.log(err);
      }
    },

    appChange() {
      this.getFirstTenReports()
      this.curr_page = 1;
      this.search_string = ''
    },

    async searchRecords() {
      this.isLoading = true;
      this.getRecordCount();

      try {
        const result = await ReportsService.searchReport(this.table_name, this.search_string.toUpperCase());
        const recordCount = await ReportsService.searchReportCount(this.table_name, this.search_string.toUpperCase());
        
        const resultData = result.data;
        this.listOfReports = resultData.rows;
        this.count = recordCount.data[0].COUNT;

        this.numOfPage = Math.ceil(this.count / 10);
        const listOfPages = [...Array(this.numOfPage).keys()].map((i) => i + 1);
        this.pages = listOfPages;

        this.isLoading = false;
      } catch (err) {
        console.log(err);
      }
    },

    async paginate(page) {
      this.isLoading = true;
      this.curr_page = page;
      const offset = this.curr_page * 10 - 10;

      try {
        const result = await ReportsService.paginateReport(this.table_name, this.search_string.toUpperCase(), offset);
        const resultData = result.data;
        this.listOfReports = resultData.rows;
        this.isLoading = false;
      } catch (err) {
        console.log(err);
      }
    },

    prevPage() {
      this.curr_page--
      this.paginate(this.curr_page)
    },

    nextPage() {
      this.curr_page++
      this.paginate(this.curr_page)
    },

    async getRecordCount() {
      try {
        const recordCount = await ReportsService.getCount(this.table_name);
        this.count = recordCount.data[0].COUNT;

        this.numOfPage = Math.ceil(this.count / 10);
        const listOfPages = [...Array(this.numOfPage).keys()].map((i) => i + 1);
        this.pages = listOfPages;

      } catch (err) {
        console.log(err);
      }
    },

    async exportRecords() {

      try {
        const result = await ReportsService.exportRecords(this.table_name, this.search_string.toUpperCase());
        const resultData = result.data;
        this.recordsToExport = resultData.rows;
      } catch(err) {
        console.log(err)
      }
      const data = this.recordsToExport;
      const fileName = this.table_name;
      const exportType = exportFromJSON.types.csv;

      if (data) exportFromJSON({ data, fileName, exportType });
    },
    
  },
};
</script>

<style scoped>
select {
  font-weight: bold;
}
</style>
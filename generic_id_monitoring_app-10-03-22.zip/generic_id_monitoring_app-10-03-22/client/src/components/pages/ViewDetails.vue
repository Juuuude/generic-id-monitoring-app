<template>
  <div>
    <div class="container d-flex mt-2 justify-content-center">
      <div
        class="card text-white bg-secondary mb-2 mt-2"
        style="max-width: 24rem; min-width: 18rem"
        v-for="(region, i) in nams"
        :key="region"
        :i="i"
      >
        <div class="card-header">NAMS {{ i }}</div>
        <div class="card-body">
          <div class="d-flex justify-content-center">
            <h6 class="card-title">Status:&nbsp;</h6>
            <h6
              :class="
                region[0].status === 'Logged in' ? 'text-warning' : 'text-info'
              "
            >
              {{ region[0].status }}
            </h6>
          </div>
          <view-details-timer
            :region="i"
            app="nams"
            v-if="region[0].status === 'Logged in'"
          ></view-details-timer>
          <p class="card-text">Last login: {{ region[1].lastLogin }}</p>
        </div>
      </div>
    </div>

    <div class="container d-flex mt-2 justify-content-center">
      <div
        class="card text-white bg-secondary mb-2"
        style="max-width: 24rem; min-width: 18rem"
        v-for="(region, i) in dctm"
        :key="region"
        :i="i"
      >
        <div class="card-header">DCTM {{ i }}</div>
        <div class="card-body">
          <div class="d-flex justify-content-center">
            <h6 class="card-title">Status:&nbsp;</h6>
            <h6
              :class="
                region[0].status === 'Logged in' ? 'text-warning' : 'text-info'
              "
            >
              {{ region[0].status }}
            </h6>
          </div>
          <view-details-timer
            :region="i"
            app="dctm"
            v-if="region[0].status === 'Logged in'"
          ></view-details-timer>
          <p class="card-text">Last login: {{ region[1].lastLogin }}</p>
        </div>
      </div>
    </div>

    <div class="container d-flex mt-2 justify-content-center">
      <div
        class="card text-white bg-secondary mb-2"
        style="max-width: 24rem; min-width: 18rem"
        v-for="(region, i) in ewp"
        :key="region"
        :i="i"
      >
        <div class="card-header">EWP {{ i }}</div>
        <div class="card-body">
          <div class="d-flex justify-content-center">
            <h6 class="card-title">Status:&nbsp;</h6>
            <h6
              :class="
                region[0].status === 'Logged in' ? 'text-warning' : 'text-info'
              "
            >
              {{ region[0].status }}
            </h6>
          </div>
          <view-details-timer
            :region="i"
            app="ewp"
            v-if="region[0].status === 'Logged in'"
          ></view-details-timer>
          <p class="card-text">Last login: {{ region[1].lastLogin }}</p>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import ViewDetailsTimer from "../timer-components/ViewDetailsTimer.vue";
export default {
  components: {
    ViewDetailsTimer,
  },
  data() {
    return {
      nams: [],
      dctm: [],
      ewp: [],
    };
  },
  props: ["id"],
  created() {
    this.updateSelectedId();
    this.loadAllUsers();
    this.$store.dispatch("setNavTitle", `Viewing ${this.id} details`);
  },
  computed: {},
  methods: {
    async loadAllUsers() {
      await this.$store.dispatch("loadAllUsers");
      const allUsers = this.$store.getters.getUsers;
      const foundUser = allUsers.find((user) => user.id === this.id);
      this.nams = foundUser["nams"][0];
      this.dctm = foundUser["dctm"][0];
      this.ewp = foundUser["ewp"][0];
      console.log(this.nams);
    },
    updateSelectedId() {
      this.$store.dispatch("setSelectedId", this.id);
    },
  },
};
</script>

<style scoped>
.card-header {
  text-transform: uppercase;
}
.text-success {
  font-weight: bold;
}
.card {
  min-width: 800px;
}
</style>
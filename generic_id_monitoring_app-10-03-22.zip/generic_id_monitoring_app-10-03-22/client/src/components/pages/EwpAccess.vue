<template>
  <div class="container d-flex">
    <div
      class="card text-white bg-secondary mt-5"
      style="min-width: 371.7px; max-width: 450px"
    >
      <h5 class="card-header">EWP Dev Region</h5>
      <div class="card-body">
        <h6 class="card-title">Last Login: {{ dLastLogin }}</h6>
        <p class="card-text">
          <base-timer
            ref="ewpDev"
            v-show="devMode === 'logout'"
            app="ewp"
            region="dev"
          ></base-timer>
        </p>
        <button :class="devClass" @click="handleAuth('devMode')">
          {{ devMode }}
        </button>
      </div>
    </div>
    <div
      class="card text-white bg-secondary mt-5"
      style="min-width: 371.7px; max-width: 450px"
    >
      <h5 class="card-header">EWP QA Region</h5>
      <div class="card-body">
        <h6 class="card-title">Last Login: {{ qLastLogin }}</h6>
        <p class="card-text">
          <base-timer
            ref="ewpQa"
            v-show="qaMode === 'logout'"
            app="ewp"
            region="qa"
          ></base-timer>
        </p>
        <button :class="qaClass" @click="handleAuth('qaMode')">
          {{ qaMode }}
        </button>
      </div>
    </div>
    <div
      class="card text-white bg-secondary mt-5"
      style="min-width: 371.7px; max-width: 450px"
    >
      <h5 class="card-header">EWP Prod Region</h5>
      <div class="card-body">
        <h6 class="card-title">Last Login: {{ pLastLogin }}</h6>
        <p class="card-text">
          <base-timer
            ref="ewpProd"
            v-show="prodMode === 'logout'"
            app="ewp"
            region="prod"
          ></base-timer>
        </p>
        <button :class="prodClass" @click="handleAuth('prodMode')">
          {{ prodMode }}
        </button>
      </div>
    </div>
  </div>
</template>
<script>
import AppAccessService from "../../services/AppAccessService";
import short from "short-uuid";

export default {
  data() {
    return {
      devMode: "login",
      qaMode: "login",
      prodMode: "login",
      dLastLogin: "N/A",
      qLastLogin: "N/A",
      pLastLogin: "N/A"
    };
  },
  created() {
    this.setData();
    this.$store.dispatch("setNavTitle", `EWP Access`);
  },
  methods: {
    async setData() {
      await this.$store.dispatch("loadAllUsers");

      if (this.getLoggedinUser["ewp"][0]["dev"][0].status === "Logged in") {
        this.devMode = "logout";
      } else {
        this.devMode = "login";
      }
      if (this.getLoggedinUser["ewp"][0]["qa"][0].status === "Logged in") {
        this.qaMode = "logout";
      } else {
        this.qaMode = "login";
      }
      if (this.getLoggedinUser["ewp"][0]["prod"][0].status === "Logged in") {
        this.prodMode = "logout";
      } else {
        this.prodMode = "login";
      }
      this.setLastLogin();
    },
    setLastLogin() {
      this.dLastLogin = this.devLastLogin;
      this.qLastLogin = this.qaLastLogin;
      this.pLastLogin = this.prodLastLogin;
    },
    async updateLastLogin() {
      await this.$store.dispatch("loadAllUsers");
      this.setLastLogin();
    },
    async handleAuth(mode) {
      this.setData();
      //defining variables to ref the timer component
      const devTimer = this.$refs.ewpDev;
      const qaTimer = this.$refs.ewpQa;
      const prodTimer = this.$refs.ewpProd;

      // determine whether the user is trying to login or logout to the app.
      this[mode] === "login" ? (this[mode] = "logout") : (this[mode] = "login");

      if (this[mode] === "logout") {
        if (mode === "devMode") {
          this.saveLoginData("DEV");
          devTimer.setData();
        } else if (mode === "qaMode") {
          this.saveLoginData("QA");
          qaTimer.setData();
        } else {
          this.saveLoginData("PROD");
          prodTimer.setData();
        }
      } else {
        if (mode === "devMode") {
          this.saveLogoutData("DEV");
          devTimer.setData();
        } else if (mode === "qaMode") {
          this.saveLogoutData("QA");
          qaTimer.setData();
        } else {
          this.saveLogoutData("PROD");
          prodTimer.setData();
        }
        this.updateLastLogin();
      }
    },
    changeTimeZone(date, timeZone) {
      if (typeof date === "string") {
        return new Date(
          new Date(date).toLocaleString("en-US", {
            timeZone,
          })
        );
      }

      return new Date(
        date.toLocaleString("en-US", {
          timeZone,
        })
      );
    },

    // saving the user login details (slid, login_time, app used and region) in oracle db
    async saveLoginData(region) {
      // to be used by firebase to display the last login date in the browser as a string
      const lastLoginDate = this.changeTimeZone(new Date(), "America/New_York");
      const formattedDate = lastLoginDate.toString().substring(0, 24);

      this.$store.dispatch("appLogin", {
        app: "ewp",
        region: region.toLowerCase(),
        lastLogin: formattedDate
      });
    },

    // saving the user session details with the specific region
    async saveLogoutData(region) {
      
      // get login and logout date and format them as yyyy-mm-dd-hh-mm-ss to be stored in oracle db
      const login_date = this.getLoginDate(region)
      const logout_date = this.getDateToday();
      
      //calculate and get the login duration of the user and its slid
      const loginDuration = this.calculateLoginTime(region);
      const slid = this.getLoggedinUser.id;
      const id = short.uuid();

      // reach to firebase database to save the state of app and last login data
      this.dispatchLogout(region);

      // reach out to oracle db to save logout date and login duration
      try {
        await AppAccessService.userLogout(
          id,
          slid,
          "fpl_ewp_access",
          "EWP",
          region,
          login_date,
          logout_date,
          loginDuration
        );
      } catch (err) {
        console.log(err);
      }
    },

    dispatchLogout(region) {
      this.$store.dispatch("appLogout", {
        app: "ewp",
        region: region.toLowerCase(),
      });
    },

    //to be used by oracledb to store the login_date/logout_date as yyyy-mm-dd-hh-mm-ss format
    getLoginDate(region) {

      let appLastLogin;
      region === "DEV" ? (appLastLogin = this.devLastLogin) : region === "QA"
      ? (appLastLogin = this.qaLastLogin) : (appLastLogin = this.prodLastLogin);

      const date = new Date(appLastLogin)
      let datetext = date.toTimeString();
      datetext = datetext.split(" ")[0];
      let formmattedD = new Date().toISOString().split("T")[0] + "-" + datetext;
      return formmattedD;
    },

    getDateToday() {
      const d = this.changeTimeZone(new Date(), "America/New_York");
      let datetext = d.toTimeString();
      datetext = datetext.split(" ")[0];
      let formmattedD = new Date().toISOString().split("T")[0] + "-" + datetext;
      return formmattedD;
    },

    calculateLoginTime(region) {
      // calculating the duration of login of the user
      let today = this.changeTimeZone(new Date(), "America/New_York");
      let appLastLogin;
      region === "DEV" ? (appLastLogin = this.devLastLogin) : region === "QA"
      ? (appLastLogin = this.qaLastLogin) : (appLastLogin = this.prodLastLogin);

      let diff = (today.getTime() - new Date(appLastLogin).getTime()) / 1000;
      let diffMins = Math.abs(Math.round((diff /= 60)));

      if (diffMins > 60) {
        let hours = Math.floor(diffMins / 60);
        let min = diffMins % 60;
        return `${hours} hour/s and ${min} minute/s`;
      } else if (diffMins < 1) {
        return `< 1 minute`;
      } else {
        return `${diffMins} minute/s`;
      }
    },
  },
  computed: {
    getLoggedinUser() {
      return this.$store.getters.getLoggedinUser;
    },
    devClass() {
      return this.devMode === "login" ? "btn btn-success" : "btn btn-danger";
    },
    qaClass() {
      return this.qaMode === "login" ? "btn btn-success" : "btn btn-danger";
    },
    prodClass() {
      return this.prodMode === "login" ? "btn btn-success" : "btn btn-danger";
    },
    devLastLogin() {
      return this.getLoggedinUser["ewp"][0]["dev"][1].lastLogin || "N/A";
    },
    qaLastLogin() {
      return this.getLoggedinUser["ewp"][0]["qa"][1].lastLogin || "N/A";
    },
    prodLastLogin() {
      return this.getLoggedinUser["ewp"][0]["prod"][1].lastLogin || "N/A";
    },
  },
};
</script>
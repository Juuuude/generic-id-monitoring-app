<template>
  <section class="vh-100">
    <div class="container py-5 h-100">
      <div class="row d-flex justify-content-center align-items-center h-100">
        <div class="col-12 col-md-8 col-lg-6 col-xl-5">
          <div v-show="dev" class="alert alert-danger" role="alert">
            Under development. Some issues may be encountered.
          </div>
          <div class="card shadow-2-strong" style="border-radius: 1rem">
            <div class="card-body p-4 text-center">
              <h3 class="mb-3 text-primary">Sign in</h3>
              <p v-if="error" class="text text-danger">{{ error }}</p>
              <div class="form-outline mb-2">
                <input
                  type="text"
                  class="form-control"
                  placeholder="SLID"
                  v-model="slid"
                  @keydown.enter="login"
                  autocomplete="on"
                />
              </div>

              <div class="form-outline mb-2">
                <input
                  type="password"
                  class="form-control"
                  placeholder="Password"
                  v-model="password"
                  @keydown.enter="login"
                  autocomplete="on"
                />
              </div>

              <!-- Checkbox -->
              <div class="form-check d-flex justify-content-start mb-3">
                <input
                  class="form-check-input"
                  type="checkbox"
                  value=""
                  id="formRememberMe"
                />
                &nbsp;
                <label class="form-check-label" for="formRememberMe">
                  Remember password
                </label>
              </div>
              <div class="row login">
                <button
                class="btn btn-primary btn-block"
                type="submit"
                @click="login"
              >
                Login
              </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>
<script>
import LoginService from "../../services/LoginService";
export default {
  data() {
    return {
      error: null,
      slid: "",
      password: "",
      dev: true,
    };
  },
  methods: {
    async login() {
      if (!this.slid) {
        return (this.error = "Please enter your SLID.");
      }
      if (!this.password) {
        return (this.error = "Please enter your password.");
      }

      let hasAccount = await LoginService.login(this.slid, this.password);
      console.log(hasAccount);
      if (hasAccount.data.slid) {
        //goto home
        this.$router.replace("/view");
        this.$store.dispatch("userLogin", {
          slid: hasAccount.data.slid,
          isLoggedin: "true",
        });
        localStorage.setItem("slid", hasAccount.data.slid);
        localStorage.setItem("isLoggedin", true);
        // this.$root.$emit("login", hasAccount);
      } else if (hasAccount.data.LoginError) {
        this.error = hasAccount.data.LoginError;
      } else if (hasAccount.data.ServerError) {
        this.error = hasAccount.data.ServerError;
      }
    },
  },
};
</script>
<style scoped>
.login {
  margin-left: 0px;
  margin-right: 0px;  
}
</style>
<template>
  <div class="container">
    <div class="row">
      <div class="col">
        <h1 class="d-block m-auto">404: Page not found!</h1>
        <img src="sadface.gif" alt="" class="d-block m-auto" />
        <router-link to="/view" type="button" class="btn btn-primary"><i class="fa-solid fa-circle-arrow-left"></i>&nbsp;Go back</router-link>
      </div>
    </div>
  </div>
</template>
<style scoped>
img {
  height: 250px;
  width: 250px;
}
h1 {
  font-weight: bolder;
  color: #444444;
}
</style>
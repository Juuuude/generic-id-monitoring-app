<template>
    <div class="container mt-5 d-flex">
        <input type="text" class="form-control" v-model="userId" placeholder="Enter SLID"> &nbsp;
        <button class="btn btn-success" @click="addUser">Add</button>
    </div>
</template>
<script>
export default {
    data() {
        return {
            userId: '',
            listOfUser: {
                    nams: [
                        {
                            dev: [
                                {
                                    status: 'Not using'
                                },
                                {
                                    lastLogin: 'N/A'
                                }, 
                                {
                                    id: ''
                                }
                            ],
                            qa: [
                                {
                                    status: 'Not using'
                                },
                                {
                                    lastLogin: 'N/A'
                                },
                                {
                                    id: ''
                                }
                            ],
                            prod: [
                                {
                                    status: 'Not using'
                                },
                                {
                                    lastLogin: 'N/A'
                                },
                                {
                                    id: ''
                                }
                            ],
                        }
                    ],
                    dctm: [
                        {
                            dev: [
                                {
                                    status: 'Not using'
                                },
                                {
                                    lastLogin: 'N/A'
                                },
                                {
                                    id: ''
                                }
                            ],
                            qa: [
                                {
                                    status: 'Not using'
                                },
                                {
                                    lastLogin: 'N/A'
                                },
                                {
                                    id: ''
                                }
                            ],
                            prod: [
                                {
                                    status: 'Not using'
                                },
                                {
                                    lastLogin: 'N/A'
                                },
                                {
                                    id: ''
                                }
                            ],
                        }
                    ],
                    ewp: [
                        {
                            dev: [
                                {
                                    status: 'Not using'
                                },
                                {
                                    lastLogin: 'N/A'
                                },
                                {
                                    id: ''
                                }
                            ],
                            qa: [
                                {
                                    status: 'Not using'
                                },
                                {
                                    lastLogin: 'N/A'
                                },
                                {
                                    id: ''
                                }
                            ],
                            prod: [
                                {
                                    status: 'Not using'
                                },
                                {
                                    lastLogin: 'N/A'
                                },
                                {
                                    id: ''
                                }
                            ],
                        }
                    ],
                },
            }
        },
        methods: {
            async addUser() {
                if (!this.userId) {
                    return alert('Please enter a slid.')
                }
                    const response = await fetch(`https://generic-id-monitoring-app-default-rtdb.firebaseio.com/users/${this.userId}.json`, {
                    method: 'PUT',
                    body: JSON.stringify(this.listOfUser)
                })
                if(!response.ok) {
                    alert('Error occured! Please try again later.')
                }else {
                    this.$router.push('/view')
                }
            }
        },
        created() {
            this.$store.dispatch('setNavTitle', `Add a user`)
        }
    }
</script>

<style scoped>
.container {
    max-width: 400px;
}
</style>
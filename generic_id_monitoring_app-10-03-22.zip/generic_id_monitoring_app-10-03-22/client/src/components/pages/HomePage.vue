<template>
  <div>
    <p class="mt-3">
      Click <router-link to="/add-user">here</router-link> to add a user
    </p>
    <div class="container mt-3">
      <table class="table table-bordered table-striped table-success">
        <thead>
          <tr>
            <th scope="col">View</th>
            <th class="table-header" scope="col">SLID</th>
            <th class="table-header" scope="col">Nams Dev</th>
            <th class="table-header" scope="col">Nams QA</th>
            <th class="table-header" scope="col">Nams Prod</th>
            <th class="table-header" scope="col">Dctm Dev</th>
            <th class="table-header" scope="col">Dctm QA</th>
            <th class="table-header" scope="col">Dctm Prod</th>
            <th class="table-header" scope="col">EWP Dev</th>
            <th class="table-header" scope="col">EWP QA</th>
            <th class="table-header" scope="col">EWP Prod</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="user in loadUsers" :key="user.id">
            <td><router-link :to="'/view/' + user.id">View</router-link></td>
            <td>{{ user.id }}</td>
            <td
              :class="
                user.nams[0].dev[0].status === 'Logged in' ? 'text-success' : ''
              "
            >
              {{ user.nams[0].dev[0].status }}
            </td>
            <td
              :class="
                user.nams[0].qa[0].status === 'Logged in' ? 'text-success' : ''
              "
            >
              {{ user.nams[0].qa[0].status }}
            </td>
            <td
              :class="
                user.nams[0].prod[0].status === 'Logged in'
                  ? 'text-success'
                  : ''
              "
            >
              {{ user.nams[0].prod[0].status }}
            </td>
            <td
              :class="
                user.dctm[0].dev[0].status === 'Logged in' ? 'text-success' : ''
              "
            >
              {{ user.dctm[0].dev[0].status }}
            </td>
            <td
              :class="
                user.dctm[0].qa[0].status === 'Logged in' ? 'text-success' : ''
              "
            >
              {{ user.dctm[0].qa[0].status }}
            </td>
            <td
              :class="
                user.dctm[0].prod[0].status === 'Logged in'
                  ? 'text-success'
                  : ''
              "
            >
              {{ user.dctm[0].prod[0].status }}
            </td>
            <td
              :class="
                user.ewp[0].dev[0].status === 'Logged in' ? 'text-success' : ''
              "
            >
              {{ user.ewp[0].dev[0].status }}
            </td>
            <td
              :class="
                user.ewp[0].qa[0].status === 'Logged in' ? 'text-success' : ''
              "
            >
              {{ user.ewp[0].qa[0].status }}
            </td>
            <td
              :class="
                user.ewp[0].prod[0].status === 'Logged in' ? 'text-success' : ''
              "
            >
              {{ user.ewp[0].prod[0].status }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script>
export default {
  computed: {
    loadUsers() {
      return this.$store.getters.getUsers;
    },
  },
  created() {
    this.loadAllUsers();
  },
  methods: {
    async loadAllUsers() {
      try {
        await this.$store.dispatch("loadAllUsers");
      } catch (error) {
        alert(error);
      }
    },
  },
};
</script>
<style scoped>
.table-header {
  min-width: 50px;
  max-width: 50px;
}
</style>
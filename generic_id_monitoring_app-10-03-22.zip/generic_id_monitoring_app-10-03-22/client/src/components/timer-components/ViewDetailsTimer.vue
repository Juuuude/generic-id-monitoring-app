<template>
  <div>
    <div class="d-flex justify-content-center">
      <!-- <p v-if="day > 0">{{ day }} {{ dayCaption }} : &nbsp;</p>
      <p v-if="hour > 0">{{ hour }} {{ hourCaption }} : &nbsp;</p>
      <p v-if="min > 0">{{ min }} {{ minCaption }} : &nbsp;</p>
      <p>{{ sec }} {{ secCaption }}</p> -->
      <p>Duration:</p>
      <p v-if="diffDays > 1">{{diffDays}} {{dayCaption}} and</p> &nbsp;
      <p v-if="diffMins === 0 && diffHrs < 1">Less than a minute</p>
      <p v-if="diffHrs > 0">{{ diffHrs }} {{hourCaption}} and&nbsp;</p>
      <p v-if="diffMins > 0">{{ diffMins }} {{minCaption}}</p>
    </div>
  </div> 
</template>

<script>
export default {
  props: ['app', 'region'],
  data() {
    return {
      diffMins: null,
      diffHrs: null,
      diffDays: null,
    };
  },
  created() {
    this.setData()
  },
  computed: {
    minCaption() {
      return this.diffMins > 1 ? "minutes" : "minute";
    },
    hourCaption() {
      return this.diffHrs > 1 ? "hours" : "hour";
    },
    dayCaption() {
      return this.diffDays > 1 ? "days" : "day";
    },
    getSelectedUser() {
      return this.$store.getters.getSelectedUser;
    },
    devLastLogin() {
      return this.getSelectedUser[this.app][0][this.region][1].lastLogin || "N/A";
    },
  },
  methods: {
    subtractDate() {
      let today = this.changeTimeZone(new Date(), "America/New_York");
      let diffMs = today - new Date(this.devLastLogin);
      this.diffDays = Math.floor(diffMs / 86400000); // days
      this.diffHrs = Math.floor((diffMs % 86400000) / 3600000); // hours
      this.diffMins = Math.round(((diffMs % 86400000) % 3600000) / 60000); // minutes
    },
    async setData(){
      await this.$store.dispatch("loadAllUsers");
      this.subtractDate()
    },
    changeTimeZone(date, timeZone) {
      if (typeof date === "string") {
        return new Date(
          new Date(date).toLocaleString("en-US", {
            timeZone,
          })
        );
      }

      return new Date(
        date.toLocaleString("en-US", {
          timeZone,
        })
      );
    },
  },
};
</script>

<style scoped>
div p {
  margin-top: 0;
  margin-bottom: 0;
  margin-left: 0;
  margin-right: 0;
  font-size: 14.8px;
}
</style>
<template>
    <div class="container">
        <div class="row">
            <div class="col">
                <img src="loading-spinner.gif" alt="" class="d-block m-auto">
            </div>
        </div>
    </div>
</template>
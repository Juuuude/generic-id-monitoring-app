<template>
  <!-- <ul class="nav nav-pills">
    <li class="nav-item">
      <router-link
        :class="homeClass"
        to="/view"
        @click="changeTitle('Generic ID Monitoring Page')"
        >Home</router-link
      >
    </li>
    <li class="nav-item">
      <router-link
        :class="reportsClass"
        to="/reports"
        @click="changeTitle('Reports Page')"
        >Reports</router-link
      >
    </li>
    <li class="nav-item">
      <router-link
        :class="namsClass"
        to="/nams"
        @click="changeTitle('NAMS DB Access')"
        >NAMS DB</router-link
      >
    </li>
    <li class="nav-item">
      <router-link
        :class="dctmClass"
        to="/documentum"
        @click="changeTitle('Documentum Access')"
        >Documentum</router-link
      >
    </li>
    <li class="nav-item">
      <router-link
        :class="ewpClass"
        to="/ewp"
        @click="changeTitle('EWP Access')"
        >EWP</router-link
      >
    </li>
    <li class="title navbar-brand">
      <p>{{ setTitle }}</p>
    </li>
  </ul> -->
  <nav class="navbar navbar-expand-lg bg-primary">
    <div class="container-fluid">
      <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <router-link
              :class="homeClass"
              to="/view"
              @click="changeTitle('Generic ID Monitoring Page')"
              >Home</router-link
            >
          </li>
          <li class="nav-item">
            <router-link
              :class="reportsClass"
              to="/reports"
              @click="changeTitle('Reports Page')"
              >Reports</router-link
            >
          </li>
          <li class="nav-item">
            <router-link
              :class="namsClass"
              to="/nams"
              @click="changeTitle('NAMS DB Access')"
              >NAMS</router-link
            >
          </li>
          <li class="nav-item">
            <router-link
              :class="dctmClass"
              to="/documentum"
              @click="changeTitle('Documentum Access')"
              >DCTM</router-link
            >
          </li>
          <li class="nav-item">
            <router-link
              :class="ewpClass"
              to="/ewp"
              @click="changeTitle('EWP Access')"
              >EWP</router-link
            >
          </li>
          <div class="container">
            <span class="navbar-brand">{{ title }}</span>
          </div>
        </ul>
        <span
          class="navbar-text btn btn-primary"
          type="button"
          @click="userLogout"
        >
          Logout <i class="fa-solid fa-right-from-bracket"></i>
        </span>
      </div>
    </div>
  </nav>
</template>
<script>
import LoginService from "../../services/LoginService";
export default {
  data() {
    return {
      title: localStorage.getItem("title"),
      slid: localStorage.getItem("slid"),
    };
  },
  computed: {
    setTitle() {
      return this.$store.getters.getNavTitle;
    },
    homeClass() {
      return this.title === "Generic ID Monitoring Page"
        ? "nav-link active"
        : "nav-link";
    },
    reportsClass() {
      return this.title === "Reports Page" ? "nav-link active" : "nav-link";
    },
    namsClass() {
      return this.title === "NAMS DB Access" ? "nav-link active" : "nav-link";
    },
    dctmClass() {
      return this.title === "Documentum Access"
        ? "nav-link active"
        : "nav-link";
    },
    ewpClass() {
      return this.title === "EWP Access" ? "nav-link active" : "nav-link";
    },
  },
  methods: {
    changeTitle(title) {
      this.$store.dispatch("setNavTitle", title);
      this.title = this.$store.getters.getNavTitle;
      localStorage.setItem("title", title);
    },
    async userLogout() {
      localStorage.removeItem("slid");
      localStorage.setItem("isLoggedin", false);
      this.$store.dispatch("userLogout");
      this.$router.push("/signin");

      try {
        await LoginService.logout();
      } catch (err) {
        console.log(err);
      }
    },
  },
};
</script>
<style scoped>
.navbar {
  padding: 0px;
  background-color: #555;
  color: #fff;
}
.navbar-brand {
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  position: absolute;
  color: white;
  font-size: 25px;
  font-family: Georgia, "Times New Roman", Times, serif;
  font-style: normal;
  font-weight: 500;
}
li {
  font-weight: bold;
  font-size: 17px;
}
.btn {
  color: #fff;
  font-weight: bold;
}
</style>
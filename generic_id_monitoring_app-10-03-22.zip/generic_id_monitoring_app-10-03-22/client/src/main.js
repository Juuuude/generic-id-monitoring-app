import { createApp } from 'vue'
import App from './App.vue'
import router from './router.js'
import store from './store/index.js'
import 'bootstrap/dist/css/bootstrap.min.css';
import '@fortawesome/fontawesome-free/css/all.css'
import '@fortawesome/fontawesome-free/js/all.js'
import { initializeApp } from "firebase/app";
import VueAwesomePaginate from "vue-awesome-paginate";
import "vue-awesome-paginate/dist/style.css";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries



// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyCurlPsoFNPbcQqjefhx9FGuHORphYHj1k",
  authDomain: "generic-id-monitoring-app.firebaseapp.com",
  databaseURL: "https://generic-id-monitoring-app-default-rtdb.firebaseio.com",
  projectId: "generic-id-monitoring-app",
  storageBucket: "generic-id-monitoring-app.appspot.com",
  messagingSenderId: "881791634577",
  appId: "1:881791634577:web:bad11dfee0f64192a0c330",
  measurementId: "G-T1DFENTW4P"
};



// Initialize Firebase
initializeApp(firebaseConfig);

import BaseTimer from './components/timer-components/BaseTimer.vue'
import BaseCard from './components/UI/BaseCard.vue'
import LoadingSpinner from './components/UI/LoadingSpinner.vue'

const app = createApp(App)
app.component('base-timer', BaseTimer)
app.component('base-card', BaseCard)
app.component('loading-spinner', LoadingSpinner)
app.use(VueAwesomePaginate)
app.use(router)
app.use(store)
app.mount('#app')




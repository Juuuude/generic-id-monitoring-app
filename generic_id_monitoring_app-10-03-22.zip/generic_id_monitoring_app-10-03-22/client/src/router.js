import { createRouter, createWebHistory } from "vue-router";
import store from './store/index.js'
import LoginPage from './components/pages/LoginPage.vue'
import HomePage from './components/pages/HomePage.vue'
import ReportsPage from './components/pages/ReportsPage.vue'
import NamsDbAccess from './components/pages/NamsDbAccess.vue'
import DocumentumAccess from './components/pages/DocumentumAccess.vue'
import EwpAccess from './components/pages/EwpAccess.vue'
import ViewDetails from './components/pages/ViewDetails.vue'
import AddUser from './components/pages/AddUser.vue'
import NotFound from './components/pages/NotFound.vue'

const router = createRouter({
    history: createWebHistory(),
    routes: [
        {
            path: '/',
            redirect: '/view'
        },
        {
            path: '/signin',
            component: LoginPage,
            beforeEnter(to, from, next) {
                const isAuthenticated = store.getters.getAuthentication === '' ? localStorage.getItem('isLoggedin') : store.getters.getAuthentication
                if (isAuthenticated === 'true') {
                    return next({path: '/view'})
                }
                return next()
            }
        },
        {
            path: '/view',
            component: HomePage,
            beforeEnter(to, from, next) {
                const isAuthenticated = store.getters.getAuthentication === '' ? localStorage.getItem('isLoggedin') : store.getters.getAuthentication
                if (isAuthenticated === 'true') {
                    return next()
                }
                return next({ path: '/signin' })
            }
        },
        {
            path: '/reports',
            component: ReportsPage,
            beforeEnter(to, from, next) {
                const isAuthenticated = store.getters.getAuthentication === '' ? localStorage.getItem('isLoggedin') : store.getters.getAuthentication
                if (isAuthenticated === 'true') {
                    return next()
                }
                return next({ path: '/signin' })
            }
        },
        {
            path: '/nams',
            component: NamsDbAccess,
            beforeEnter(to, from, next) {
                const isAuthenticated = store.getters.getAuthentication === '' ? localStorage.getItem('isLoggedin') : store.getters.getAuthentication
                if (isAuthenticated === 'true') {
                    return next()
                }
                return next({ path: '/signin' })
            }
        },
        {
            path: '/documentum',
            component: DocumentumAccess,
            beforeEnter(to, from, next) {
                const isAuthenticated = store.getters.getAuthentication === '' ? localStorage.getItem('isLoggedin') : store.getters.getAuthentication
                if (isAuthenticated === 'true') {
                    return next()
                }
                return next({ path: '/signin' })
            }
        },
        {
            path: '/ewp',
            component: EwpAccess,
            beforeEnter(to, from, next) {
                const isAuthenticated = store.getters.getAuthentication === '' ? localStorage.getItem('isLoggedin') : store.getters.getAuthentication
                if (isAuthenticated === 'true') {
                    return next()
                }
                return next({ path: '/signin' })
            }
        },
        {
            path: '/view/:id',
            component: ViewDetails,
            props: true,
            beforeEnter(to, from, next) {
                const isAuthenticated = store.getters.getAuthentication === '' ? localStorage.getItem('isLoggedin') : store.getters.getAuthentication
                if (isAuthenticated === 'true') {
                    return next()
                }
                return next({ path: '/signin' })
            },
        },
        {
            path: '/add-user',
            component: AddUser,
            beforeEnter(to, from, next) {
                const isAuthenticated = store.getters.getAuthentication === '' ? localStorage.getItem('isLoggedin') : store.getters.getAuthentication
                if (isAuthenticated === 'true') {
                    return next()
                }
                return next({ path: '/signin' })
            }
        },
        {
            path: '/:notFound(.*)',
            component: NotFound
        }
    ]

})

export default router
<template>
  <div>
    <the-nav v-if="isLoggedin === 'true'"></the-nav>
    <router-view></router-view>
    <div class="footer-1">
      <p>© 2022 Accenture</p>
    </div>
    <div class="footer-2">
      <p>For suggestions/bug report, click <a href="mailto:jan.aquino@fpl.com">here</a></p>
    </div>
  </div>
</template>

<script>
import TheNav from "./components/UI/TheNav.vue";

export default {
  name: "App",

  components: {
    TheNav,
  },
  data() {
    return {};
  },

  computed: {
    isLoggedin() {
      const status = this.$store.getters.getAuthentication;
      if (!status) {
        return localStorage.getItem("isLoggedin");
      } else {
        return status;
      }
    },
  },
};
</script>
<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 0px;
}
.footer-1 {
   position: fixed;
   left: 0;
   bottom: 0;
   color: white;
   text-align: center;
   font-size: 10px;
   margin-bottom: 0px;
}
.footer-2 {
   position: fixed;
   right: 0;
   bottom: 0;
   color: white;
   text-align: center;
   font-weight: bold;
   font-size: 11px;
   margin-bottom: 0px;
}
</style>
